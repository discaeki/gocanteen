import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pesan',
  templateUrl: './pesan.page.html',
  styleUrls: ['./pesan.page.scss'],
})
export class PesanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
