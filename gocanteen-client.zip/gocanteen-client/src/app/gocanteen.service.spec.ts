import { TestBed } from '@angular/core/testing';

import { GocanteenService } from './gocanteen.service';

describe('GocanteenService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GocanteenService = TestBed.get(GocanteenService);
    expect(service).toBeTruthy();
  });
});
