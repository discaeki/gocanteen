import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pesanan',
  templateUrl: './pesanan.page.html',
  styleUrls: ['./pesanan.page.scss'],
})
export class PesananPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
