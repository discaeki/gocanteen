import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kantin',
  templateUrl: './kantin.page.html',
  styleUrls: ['./kantin.page.scss'],
})
export class KantinPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
