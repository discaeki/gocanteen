import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KantinPage } from './kantin.page';

describe('KantinPage', () => {
  let component: KantinPage;
  let fixture: ComponentFixture<KantinPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KantinPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KantinPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
